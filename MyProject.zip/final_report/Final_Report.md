# Final Report — Hospital Management System (HMS)

## Project summary
Hospital Management System (HMS) automates patient registration, appointments, doctor management, billing and basic reporting for hospital operations. This package includes a ready demo server, database schema, Confluence pages, Jira import CSV, test cases and effort estimation.

## What is included
- Confluence pages to paste into your Confluence space.
- Jira CSV to bulk import epics, stories and sample bug.
- GitHub project skeleton with a minimal Flask server and in-memory data store.
- ER diagram and SQL schema for database.
- Effort estimation spreadsheet and final report draft.

## How to submit
1. Push repository to GitHub and include screenshots of running server and commits.
2. Import Jira CSV into your college Jira project (change project key if needed).
3. Paste Confluence pages into the Confluence space and attach the ER diagram and SQL.
4. Zip the repository or provide GitHub link for upload.

## Notes
- Replace team member names and USNs before submission.
- For production, replace in-memory DB with Postgres/MySQL and enable authentication & HTTPS.